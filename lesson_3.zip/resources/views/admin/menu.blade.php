<a href="{{ route('home') }}">Главная</a>
<a href="{{ route('admin.index') }}">Админка</a>
<a href="{{ route('admin.test') }}">Тест</a>
