@extends('layouts.app')

@section('title')
    @parent {{$news['title'] ?? ''}}
@endsection

@section('menu')
    @include('menu')
@endsection

@section('content')
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-12">
                @if($news)
                <h3 class="text-center">{{  $news['title'] }}</h3>
                    @if(!$news['isPrivate'])
                        <p class="text-center">{{ $news['text']  }}</p>
                    @else
                        <p class="text-center">Зарегистрируйтесь для просмотра</p>
                    @endif
                @else
                    <p class="text-center">Новость не найдена</p>
                @endif
            </div>
        </div>
    </div>
@endsection

