@extends('layouts.app')

@section('title')
    @parent Категория
@endsection

@section('menu')
    @include('menu')
@endsection


@section('content')
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-12">
                <h3 class="text-center">Новости категории {{ $category }}</h3>
                <ul class="list-group">
                    @forelse($news as $item)
                        <li class="list-group-item"><a href="{{route('news.one', $item['id'])}}">{{ $item['title'] }}</a></li>
                    @empty
                        <p class="text-center">Нет категорий</p>
                    @endforelse
                </ul>
            </div>
        </div>
    </div>
@endsection
