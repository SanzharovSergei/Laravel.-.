@extends('layouts.app')

@section('title')
    @parent Новости
@endsection

@section('menu')
    @include('menu')
@endsection

@section('content')
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-12">
                <h3 class="text-center">Новости</h3>
                <ul class="list-group">
                    @forelse($news as $item)
                    <li class="list-group-item"><a href="{{route('news.one', $item['id'])}}">{{$item['title']}}</a></li>
                    @empty
                        <p>Нет новостей</p>
                    @endforelse
                </ul>
            </div>
        </div>

        <div class="row justify-content-center mt-3">
            <div class="col-md-6">
                <div class="card">
                    <div class="card-body">
                        <h5 class="card-title">Добавить новость</h5>
                        <form>
                            <div class="form-group">
                                <label for="">Заголовок</label>
                                <input type="text" class="form-control" placeholder="Заголовок">
                            </div>
                            <div class="form-group">
                                <label for="">Текст</label>
                                <textarea class="form-control" placeholder="Текст"></textarea>
                            </div>
                            <button type="submit" class="btn btn-default">Отправить</button>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
@endsection



