<a href="{{ route('home') }}">Главная</a>
<a href="{{ route('news.index') }}">Новости</a>
<a href="{{ route('news.category.index') }}">Категории</a>
<a href="{{ route('about') }}">О нас</a>
<a href="{{ route('admin.index') }}">Админка</a>
