@extends('layouts.app')

@section('title')
    @parent О нас
@endsection

@section('content')
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-12">
                <h3 class="text-center">О нас</h3>
            </div>
        </div>
    </div>
@endsection

