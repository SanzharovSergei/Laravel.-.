<?php $__env->startSection('title'); ?>
    ##parent-placeholder-3c6de1b7dd91465d437ef415f94f36afc1fbc8a8## <?php echo e($news['title'] ?? ''); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('menu'); ?>
    <?php echo $__env->make('menu', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-12">
                <?php if($news): ?>
                <h3 class="text-center"><?php echo e($news['title']); ?></h3>
                    <?php if(!$news['isPrivate']): ?>
                        <p class="text-center"><?php echo e($news['text']); ?></p>
                    <?php else: ?>
                        <p class="text-center">Зарегистрируйтесь для просмотра</p>
                    <?php endif; ?>
                <?php else: ?>
                    <p class="text-center">Новость не найдена</p>
                <?php endif; ?>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/laravel/resources/views/news/one.blade.php ENDPATH**/ ?>