<!doctype html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link rel="stylesheet" href="<?php echo e(asset('css/app.css')); ?>">
    <title><?php $__env->startSection('title'); ?> Агрегатор | <?php echo $__env->yieldSection(); ?></title>
</head>
<body>
    <?php echo $__env->yieldContent('menu'); ?>
    <?php echo $__env->yieldContent('content'); ?>
    <script src="<?php echo e(asset('js/app.js')); ?>" ></script>
</body>
</html>
<?php /**PATH /var/www/laravel/resources/views/layouts/main.blade.php ENDPATH**/ ?>