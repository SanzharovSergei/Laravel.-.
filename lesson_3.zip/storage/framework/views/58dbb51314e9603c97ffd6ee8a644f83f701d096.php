<a href="<?php echo e(route('home')); ?>">Главная</a>
<a href="<?php echo e(route('news.index')); ?>">Новости</a>
<a href="<?php echo e(route('news.category.index')); ?>">Категории</a>
<a href="<?php echo e(route('about')); ?>">О нас</a>
<a href="<?php echo e(route('admin.index')); ?>">Админка</a>
<?php /**PATH /var/www/laravel/resources/views/menu.blade.php ENDPATH**/ ?>